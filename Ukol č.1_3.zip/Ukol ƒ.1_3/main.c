#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

int main()
{
    uint64_t num, num2=1, i;

    printf("Zadavejte pouze cela, kladna cisla 0 - 20.\n");
    printf("Zvolte cislo pro vypocet faktorialu\n");
    scanf("%"PRId64 , &num);

    if(num<0)
        {
            printf("Zadejte kladne cislo");
        }
    else if (num>20)
        {
            printf("Zadejte mensi cislo");
        }
    else
        {
            for(i=1; num>=i; i++)
                {
                    num2=num2*i;
                }
            printf("Vysledek %"PRId64"! je %"PRId64" \n", num, num2);
        }

    return 0;

}
