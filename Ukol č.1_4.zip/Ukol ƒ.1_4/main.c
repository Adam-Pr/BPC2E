#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char *argv[])
{
    if(argc != 4) {
        printf("Neplatny pocet argumentu.\n");
        return EXIT_FAILURE;
    }

    char *fileNameArg = argv[1];
    char *numOfRowsArg = argv[2];
    char *separatorArg = argv[3];

    int numOfRows = atoi(numOfRowsArg);
    int currentRow = 0;

    FILE* file = fopen(fileNameArg, "r");
    char line[1000000]; //limit 1 milion znaku na radek

    while (fgets(line, sizeof(line), file) && currentRow < numOfRows) {
        currentRow++;
        /*V zadani neni specifikovano jakym zpusobem radek vypsat na obrazovku.
          Volime proto nejjednodussi zpusob a vykreslime ho v puvodni podobe.*/
        printf("%s", line);
    }

    fclose(file);

    return EXIT_SUCCESS;
}
