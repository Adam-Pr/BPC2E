#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    if(argc != 2) {
        printf("Neplatny pocet argumentu.\n");
        return EXIT_FAILURE;
    }

    char *fileNameArg = argv[1];

    FILE* file = fopen(fileNameArg, "rb");

    char buffer[10]; //prvnich 10 bytu BMP headeru

    /*Precteme 3 zakladni parametry.*/

    fread(buffer,sizeof(buffer),1,file);

    char signatureText[3] = {0};
    strncpy(signatureText, buffer, 2);

    int fileSize = buffer[2] + (buffer[3] << 8) + (buffer[4] << 16) + (buffer[5] << 24);
    int dataOffset = buffer[6] + (buffer[7] << 8) + (buffer[8] << 16) + (buffer[9] << 24);

    printf("Signature: %s\n", signatureText);
    printf("FileSize: %d\n", fileSize);
    printf("DataOffset: %d\n", dataOffset);

    fclose(file);

    return EXIT_SUCCESS;
}
